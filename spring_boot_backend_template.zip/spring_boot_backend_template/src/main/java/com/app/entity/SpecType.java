package com.app.entity;

public enum SpecType 
{
	Dentist,Dermatologist,Neurologist

}
