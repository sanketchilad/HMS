package com.app.services;

import java.util.List;

import com.app.dto.AddPatientDto;
import com.app.entity.Patient;
import com.app.entity.Person;

public interface PatientService 
{
	List<Patient> getAllPatients();
	public String addPatient(AddPatientDto addpatient);
	public String deletePatient(Long id);
	Patient updatePatient(Patient patient,Long id);
	
	

}
